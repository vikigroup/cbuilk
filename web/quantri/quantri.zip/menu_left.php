<ul class="menu_admin">
    <li class="active_menu_admin">
        <div class="arrow_active"></div>
        <span class="icon_menu1"></span><a href="<?php echo $host_link_full."/quantri/index.php";?>" title="">Trang chủ</a>
    </li>
    <li>
        <span class="icon_menu2"></span><a href="index.php?act=config_shop" title="">Cấu hình</a>
    </li>
    <li>
        <span class="icon_menu3"></span><a href="#" title="">Sản phẩm</a>
        <ul class="menu_child">
            <li><a href="index.php?act=item_category" title="">&bull; Danh mục </a></li>
            <li><a href="index.php?act=item" title="">&bull; Sản phẩm</a></li>
            <li><a href="index.php?act=order" title="">&bull; Đơn hàng</a></li>
        </ul><!-- End .menu_child -->
    </li>
     <li>
        <span class="icon_menu3"></span><a href="#" title="">Thông tin</a>
        <ul class="menu_child">
            <li><a href="index.php?act=news_category" title="">&bull; Danh mục </a></li>
            <li><a href="index.php?act=news" title="">&bull; Tin tức</a></li>
        </ul><!-- End .menu_child -->
    </li>
    
    <li>
        <span class="icon_menu9"></span><a href="index.php?act=adv" title="">Quảng cáo</a>
    </li>
    <li>
        <span class="icon_menu10"></span><a href="index.php?act=support" title="">Hỗ trợ</a>
    </li>
    <li>
        <span class="icon_menu11"></span><a href="index.php?act=slider" title="">Slider</a>
    </li>
    <li>
        <span class="icon_menu12"></span><a href="index.php?act=video" title="">Video</a>
    </li>
    <li>
        <span class="icon_menu12"></span><a href="index.php?act=link" title="">Liên kết nhanh</a>
    </li>
     <li>
        <span class="icon_menu12"></span><a href="index.php?act=download" title="">Download</a>
    </li>
</ul><!-- End .menu_admin -->