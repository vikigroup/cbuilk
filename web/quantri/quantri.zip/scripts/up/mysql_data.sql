
CREATE TABLE users(
uid INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR[200],
image VARCHAR[1000]);

INSERT into users (uid, name, image) VALUES (1,'Abhishek Ahlawat','unknown.jpg'),(2,'wtfdiary','unknown.gif'),(3,'Ankush bansal','unknown.png');
