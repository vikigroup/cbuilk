<div id="num_ad_footer">
    <div class="foot1">
      Copyright © <a href="#" title="" target="_blank">jbs.vn</a> - All rights reserved.
    </div>
    
    <div class="foot2">JBS MANEGAMNET 2.0</div>
    
    <div class="clear"></div>

</div><!-- End #num_ad_footer -->