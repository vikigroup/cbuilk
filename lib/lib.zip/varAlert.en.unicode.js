﻿var mustInputDM  = 'Please enter "category name" !';
var mustNumber   = '"Thứ tự sấp xếp" phải là số !';

var varUid   = 'Username';
var varPwd   = 'Password';

var mustInput_Name      = 'Please enter "full name" !';
var mustInput_Company   = 'Please enter "company name" !';
var mustInput_Address   = 'Please enter "address" !';
var mustInput_city      = 'Please enter "city" !';
var mustInput_Tel       = 'Please enter "telephone" !';
var mustInterger_Tel    = '"Telephone" must is number !';
var mustInput_Email     = 'Please enter "e-mail" !';
var invalid_Email       = '"E-mail" wrongs format !';
var mustInput_Uid       = 'Please enter "username" !';
var mustInput_PwdOld    = 'Please enter "old password" !';
var mustInput_Pwd       = 'Please enter "password" !';
var mustInput_Pwd2      = 'Please enter "confirm password" !';
var identicalPassword   = 'Two password must are similar !';
var mustSelect_Sex      = 'Please select "sex" !';
var mustSelect_Country  = 'Please select "country" !';
var mustLength4_Uid     = '"Username" must greater than or equal to 4 charecters !';
var mustLength4_Pwd     = '"Password" must greater than or equal to 4 charecters !';
var mustLength6_Uid     = '"Username" must greater than or equal to 6 charecters !';
var mustLength6_Pwd     = '"Password" must greater than or equal to 6 charecters !';
var mustInput_Robust    = 'Please enter "confirm string" !';

var mustInput_Detail    = 'Please enter "detail" !';
var mustInput_Search    = 'Please enter "keyword to search" !';