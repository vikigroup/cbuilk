<?
define('_FIRST_PAGE'      ,'FIRST PAGE');
define('_HOME'            ,'HOME');
define('_INTRO'           ,'INTRODUCT');
define('_CONTACT'         ,'CONTACT');
define('_ABOUT'           ,'ABOUT US');
define('_HISTORY'         ,'HISTORY');
define('_NEWSEVENT'       ,'NEWS & EVENT');
define('_NEWS'            ,'NEWS');
define('_EVENT'           ,'EVENT');
define('_DOC'             ,'DOCUMENT');
define('_PROJECT'         ,'PROJECT');
define('_PRODUCT_CATEGORY','PRODUCT CATEGORY');
define('_PRODUCT'         ,'PRODUCT');
define('_PRODUCT_NEW'     ,'NEW PRODUCT');
define('_PRODUCT_SPECIAL' ,'SPECIAL PRODUCT');
define('_MEMBER'          ,'MEMBER');
define('_SERVICE'         ,'SERVICE');
define('_SITEMAP'         ,'SITEMAP');
define('_SPECIAL'         ,'LIMITED SPECIALITY');
define('_RECRUIT'         ,'RECRUIT');

define('_LINK'            ,'LINK WEBSITE');
define('_WEATHER'         ,'WEATHER');
define('_GOLD'            ,'GOLD');
define('_FOREX'           ,'FOREX');
define('_STOCK'           ,'STOCK');
define('_ONLINE'          ,'SUPPORT ONLINE');
define('_SEARCH'          ,'SEARCH');
define('_GOOGLE'          ,'SEARCH BY GOOGLE');
define('_SEARCH_ADVANCE'  ,'ADVANCE SEARCH');
define('_TOTAL'           ,'TOTAL ACCESS');
define('_ADVERTISEMENT'   ,'ADVERTISEMENT');
define('_IDEA'            ,'IDEA');
define('_FORUM'           ,'FORUM');
define('_ORTHERINFO'      ,'ORTHER INFOMATION');

define('_UID'             ,'Username');
define('_PWD'             ,'Password');
define('_REGISTRY'        ,'Registry');
define('_LOGIN'           ,'Login');
define('_LOGOUT'          ,'Logout');
define('_FORGOTPASS'      ,'Forgot password');

define('_MEMBER'          ,'Member');
define('_GUEST'           ,'Guest');

define('_CUSTOMER'        ,'CUSTOMER');
define('_PARTNER'         ,'PARTNER');

define('_INTRO1'          ,'Introduction');
define('_INTRO2'          ,'Diagram');
define('_INTRO3'          ,'Staff');
define('_INTRO4'          ,'Norm');
define('_PARTNER1'        ,'Foreign');
define('_PARTNER2'        ,'Inland');
define('_CUSTOMER1'       ,'Project');
define('_CUSTOMER2'       ,'Agency');

define('_NEWS_GOOD'       ,'SALIENT NEWS');
define('_PROMOTION'       ,'PROMOTION - RECRUIT');
define('_ADVICE'          ,'ADVICE');
?>