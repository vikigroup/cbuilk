<?
define('_HOME'            ,'TRANG CHỦ');
define('_INTRO'           ,'Giới Thiệu');
define('_CONTACT'         ,'Liên Hệ');
define('_SITEMAP'		  ,'SiteMap');
define('_ABOUT'           ,'GIỚI THIỆU CHUNG');
define('_HISTORY'         ,'LỊCH SỬ CÔNG TY');
define('_NEWSEVENT'       ,'TIN TỨC & SỰ KIỆN');
define('_NEWS'            ,'TIN TỨC');
define('_EVENT'           ,'SỰ KIỆN');
define('_DOC'             ,'TÀI LIỆU');
define('_PROJECT'         ,'DỰ ÁN');
define('_PRODUCT_CATEGORY','DANH MỤC SẢN PHẨM');
define('_PRODUCT'         ,'SẢN PHẨM');
define('_PRODUCT_NEW'     ,'SẢN PHẨM MỚI');
define('_PRODUCT_SPECIAL' ,'SẢN PHẨM ĐẶC TRƯNG');
define('_MEMBER'          ,'THÀNH VIÊN');
define('_SERVICE'         ,'DỊCH VỤ');
define('_SITEMAP'         ,'SƠ ĐỒ SITE');
define('_SPECIAL'         ,'LĨNH VỰC HOẠT ĐỘNG');
define('_HOTNEWS'         ,'Tin nóng');
define('_LINK'            ,'LIÊN KẾT WEBSITE');
define('_WEATHER'         ,'THỜI TIẾT');
define('_GOLD'            ,'GIÁ VÀNG 9999');
define('_FOREX'           ,'TỶ GIÁ');
define('_STOCK'           ,'CHỨNG KHOÁN');
define('_ONLINE'          ,'HỔ TRỢ TRỰC TUYẾN');
define('_SEARCH'          ,'TÌM KIẾM');
define('_GOOGLE'          ,'TÌM KIẾM VỚI GOOGLE');
define('_SEARCH_ADVANCE'  ,'TÌM KIẾM NÂNG CAO');
define('_TOTAL'           ,'Thống kê truy cập');
define('_ADVERTISEMENT'   ,'QUẢNG CÁO');
define('_IDEA'            ,'Ý KIẾN');
define('_ORTHERINFO'      ,'THÔNG TIN KHÁC');
define('_THONGTIN'		  ,'Thông tin liên hệ');
define('_SOCIAL'		  ,'Chia sẻ cộng đồng');
define('_UID'             ,'Tên đăng nhập');
define('_PWD'             ,'Mật khẩu');
define('_REGISTRY'        ,'Đăng ký');
define('_LOGIN'           ,'Đăng nhập');
define('_LOGOUT'          ,'Đăng Xuất');
define('_FORGOTPASS'      ,'Quên mật khẩu');
define('_MEMBER'          ,'Thành viên');
define('_GUEST'           ,'Khách'); 
define('_TOTAL'           ,'Thống kê truy cập'); 
define('_CUSTOMER'        ,'KHÁCH HÀNG');
define('_SUPPORT'		  ,'Hỗ trợ trực tuyến');
define('_HOTLINE'		  ,'HOTLINE');
define('_MOREINFO'        ,'TIN CẦN BIẾT');
define('_BANCANBIET'	  ,'Bạn cần biết');
define('_HOTLINE'		  ,'Hotline:');
define('_SUKIEN'		  ,'Sự kiện');
define('_PARTNER'		  ,'Đối tác quảng cáo');
define('_NHAPHO'		  ,'NHÀ PHỐ');
define('_BIETTHU1'		 ,'Biệt thự - Vườn');
define('_NOITHATGD'		 ,'NỘI THẤT GIA ĐÌNH');
define('_NOITHATVP'		 ,'NỘI THẤT VĂN PHÒNG');
define('_NOITHATVP2'	,'NỘI THẤT VP');
define('_PROJECTVIEWMOST' ,'CÔNG TRÌNH XEM NHIỀU NHẤT');
define('_NEWSVIEWMOST'	 ,'TIN ĐỌC NHIỀU NHẤT');
define('_BIETTHUVUON'    ,'BIỆT THỰ - VƯỜN');
define('_NOITHAT'  	     ,'Nội thất');
define('_VANPHONG'       ,'Văn phòng');
define('_DOGO'			,'ĐỒ GỖ NỘI THẤT');
define('_THIETKE'		,'THIẾT KẾ KIẾN TRÚC');
define('_THICONG'		,'THI CÔNG XÂY DỰNG');
define('_TRANGTRI'		,'TRANG TRÍ NỘI THẤT');
define('_DATHICONG'		,'ĐÃ THI CÔNG');
define('_TUVAN' 		,'TƯ VẤN GIÁM SÁT CTXD');
//--------------------------------------- Lang menu
define('_QUYTRINH'		,'Quy trình thi công');
define('_CHIASE'		,'Chia sẻ kinh nghiệm');
define('_PHONGTHUY'		,'Phong thủy');
define('_KHONGGIAN'		,'Không gian sống');
define('_NOITHATDEP'	,'Nội thất đẹp');
define('_KIENTRUCDEP'	,'Kiến trúc đẹp');
define('_KHAMPHA'		,'KHÁM PHÁ');
define('_TINTUC'		,'Tin tức - Sự kiện');
define('_LIENHE'		,'Liên hệ');
define('_DIENDAN'		,'Diễn đàn');
define('_BIETTHU'		,'Biệt thự');
define('_NOITHATVP1'	,'Nội thất văn phòng');
define('_NOITHATDD'		,'Nội thất dân dụng');
define('_BIETTHUVUON'	,'Biệt thự - vườn');
define('_NOITHATGD'		,'Nội thất gia đình');
define('_NOITHATDANDUNG'	,'Nội thất dân dụng');
define('_NOITHATKHAC'	,'NỘI THẤT KHÁC');
define('_THUVIEN'		,'Thư viện kiến trúc');
define('_GIAYDANTUONG'	,'Giấy dán tường');
define('_DAHOACUONG'	,'Đá hoa cương');
define('_HOIDAPKTS'		,'Hỏi đáp cùng kiến trúc sư');
define('_HOIDAPKTS1'	,'Hỏi & đáp với kiến trúc sư');
define('_KINHNGHIEM'	,'Kinh nghiệm kiến trúc sư');
define('_TUVANVLXD'		,'Tư vấn vật liệu xây dựng');
define('_DOGONT'	    ,'Đồ gỗ nội thất');
define('_NHOMKINH'		,'Nhôm kính');
define('_SATTRANGTRI'	,'Sắt trang trí');
define('_TRANTHACHCAO'	,'Trần thạnh cao');
define('_KIENTRUC'		,'Kiến trúc');
define('_NOITHAT1'		,'Nội thất');
define('_XAYDUNG'		,'Xây dựng');
define('_KIENTRUCCODIEN'	,'Kiến trúc cổ điển');

define('_KTDUONGDAI'	,'KT đương đại');
define('_ANTUONG'		,'Ấn tượng nội thất');
define('_DOGOST'		,'Đồ gỗ sang trọng');
define('_HOINHO'		,'Thăng hoa KT Việt');
define('_KHAMPHAKT'		,'KP KT nhân loại');

define('_GIAYDANTUONG'		,'Giấy dán tường');
define('_DAHOACUONG'	,'Đá hoa cương');
define('_NHOMKINH'		,'Nhôm kính');
define('_SATTRANGTRI'		,'Sắt trang trí');
define('_TRANTHACHCAO'		,'Trần thạch cao');

//------------------------- cong trinh da thi cong

define('_NHAPHODTC'			,'Nhà phố');
define('_BIETTHUDTC'		,'Biệt thự vườn');
define('_NOITHATGDDTC'		,'Nội thất gia đình');
define('_NOITHATVPDTC'		,'Nội thất VP');

//------------------------- menu main phong thuy
define('_UNGDUNGKIENTRUC'		,'ỨNG DỤNG ');
define('_PHONGTHUYNO'		    ,'PHONG THỦY NHÀ Ở');
define('_PHONGTHUYNT'		    ,'PHONG THỦY NỘI THẤT');
define('_UNGDUNGPHONGTHUY'		,'ỨNG DỤNG PHONG THỦY');
define('_PHONGTHUYVP'		    ,'PHONG THỦY VĂN PHÒNG');
define('_LINHVATPHONGTHUY'		,'LINH VẬT PHONG THỦY');
define('_LINHVATDAQUY'		    ,'LINH VẬT ĐÁ QUÝ');
define('_PHONGTHUYPN'		    ,'PHONG THỦY PHÒNG NGỦ');
define('_5YEUTO'		        ,'5 YẾU TỐ PHONG THỦY');
define('_PHONGTHUYKHAC'		    ,'CÁC THÔNG TIN PHONG THỦY KHÁC');


define('_PHONGTHUYNO1'		    ,'PT NHÀ Ở');
define('_PHONGTHUYNT1'		    ,'PT NỘI THẤT');
define('_PHONGTHUYVP1'		    ,'PT VĂN PHÒNG');
define('_LINHVATPHONGTHUY1'		,'LINH VẬT PT');
define('_LINHVATDAQUY1'		    ,'PT ĐÁ QUÝ');
define('_PHONGTHUYPK1'		    ,'PT PHÁP KHÍ');
define('_PHONGTHUYPN1'		    ,'PT PHÒNG NGỦ');
define('_5YEUTO1'		        ,'5 YẾU TỐ PT');



define('_PTN0'		,'Phong thủy nhà ở');
define('_PTKT'		,'Phong thủy kiến trúc');
define('_PTNT'		,'Phong thủy nội thất');
define('_PTXD'		,'Phong thủy xây dựng');
define('_PTSHT'		,'Sơn - hướng và trạch trong phong thủy');
define('_TINTUC2'		,'TIN TỨC');
define('_HOME2'		,'PHONG THỦY');

define('_LIENHE2'		,'LIÊN HỆ');

//------------------------------------------ Lang thiet ke web
define('_TUVANTK'	      ,'tư vấn thiết kế');
define('_WEBSITE'	      ,'website mẫu');
define('_MAUTK'			  ,'mẫu thiết kế');
define('_KH'			  ,'khách hàng');
define('_SERVICE'	      ,'Dịch vụ chính');
define('_THIETKEWEB'      ,'thiết kế website');
define('_THIETKEDOHOA'    ,'đồ họa - in ấn');
define('_DOMAIN'		  ,'tên miền - domain');
define('_LUUTRU'		  ,'lưu trữ - hosting');
define('_SERVER'		  ,'máy chủ - server');
define('_EMAILSERVER'     ,'Email server');
define('_MANAGE'          ,'quản trị website');
define('_QUANGBA'         ,'quảng bá thương hiệu');
define('_NETWORK'		  ,'dịch vụ mạng máy tính');
define('_SOFTWARE'	      ,'phần mềm');
define('_RESELLER'        ,'đại lý');
//------------------------------------------- cac goi website
define('_CACGOIWEB'         ,'các gói tk web');
define('_TKWEBSITE'         ,'Thiết kế website');
define('_WEBTRONGOI'      	,'Web trọn gói');
define('_WEBGIARE'      	,'Web giá rẻ');
define('_WEBDOANHNGHIEP'    ,'Web doanh nghiệp');
define('_WEBTMDT'        	,'Web thương mại điện tử');
define('_WEBTRONGOI1'      	,'Thiết kế website trọn gói');
define('_WEBGIARE1'      	,'Thiết kế website giá rẻ');
define('_WEBDOANHNGHIEP1'    ,'Thiết kế website doanh nghiệp');
define('_WEBTMDT1'        	,'Thiết kế website thương mại điện tử');
define('_WEBTK'          	,'Website đã thiết kế');
define('_DANGKY'          	,'Đăng ký thiết kế web');
define('_HOIDAP'          	,'Hỏi đáp thiết kế website');
//------------------------------------------- Doa hoa - In an
define('_LOGO'              ,'Thiết kế Logo');
define('_BROCHURE'          ,'Thiết kế Brochure');
define('_NAMECARD'      	,'Thiết kế Letter head');
define('_CATELOGUE'      	,'Thiết kế Catalogue');
define('_LOGOTK'          	,'Logo đã thiết kế');
define('_BROCHURETK'        ,'Brochure đã thiết kế');
define('_NAMECARDTK'        ,'Letter head đã thiết kế');
define('_CATALOGUETK'       ,'Catalogue đã thiết kế');
?>
